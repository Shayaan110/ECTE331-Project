package Project3;


public class PriorityInversionDemo {
	public static void runPInv() throws InterruptedException{
		
		//creating an object of the shared resource
		MotorController MC=new MotorController();
		
		//setting the main thread to the lowest priority
		Thread.currentThread().setPriority(1);
		
		//creating object of class Logger and setting to low priority
		Logger logg=new Logger(MC);
		logg.setPriority(3);
		
		//creating object of class MotionPlanner and setting to medium priority
		MotionPlanner MP=new MotionPlanner();
		MP.setPriority(5);
		
		//creating object of class SafetyMonitor and setting to high priority
		SafetyMonitor SM=new SafetyMonitor(MC);
		SM.setPriority(9);
		
		//starting the threads
		logg.start();
		Thread.sleep(100);
		MP.start();
		Thread.sleep(1200); //play with the sleep to force priority inversion
		SM.start();
		
		//stopping the execution of the main thread until all other threads complete
		logg.join();
		MP.join();
		SM.join();
		
		System.out.println("\n            Priority Inversion Summary            \n");
		
		System.out.println("SafetyMonitor Thread starts at "+SM.start_time);
		System.out.println("SafetyMonitor Thread ends at "+SM.end_time);
		System.out.println("SafetyMonitor Thread waits for lock at "+SM.start_wait_time);
		System.out.println("SafetyMonitor Thread gets lock at "+SM.end_wait_time);
		System.out.println("SafetyMonitor Thread enters critical section at "+SM.critical_start_time);
		System.out.println("SafetyMonitor Thread exits critical section at "+SM.critical_end_time);
		System.out.println("Time taken for SafetyMonitor Thread to finish execution:"+SM.thread_execution_time);
		System.out.println("Time taken for SafetyMonitor Thread to acquire lock:"+SM.lock_acquire_time);
		System.out.println("Time taken for SafetyMonitor Thread to finish execution of critical section: "+SM.critical_time);
		System.out.println();
		
		System.out.println("MotionPlanner Thread starts at "+MP.start_time);
		System.out.println("MotionPlanner Thread ends at "+MP.end_time);
		System.out.println("Time taken for MotionPlanner Thread to finish execution:"+MP.thread_execution_time);
		System.out.println();
		
		System.out.println("Logger Thread starts at "+logg.start_time);
		System.out.println("Logger Thread ends at "+logg.end_time);
		System.out.println("Logger Thread waits for lock at "+logg.start_wait_time);
		System.out.println("Logger Thread gets lock at "+logg.end_wait_time);
		System.out.println("Logger Thread enters critical section at "+logg.critical_start_time);
		System.out.println("Logger Thread exits critical section at "+logg.critical_end_time);
		System.out.println("Time taken for Logger Thread to finish execution:"+logg.thread_execution_time);
		System.out.println("Time taken for Logger Thread to acquire lock:"+logg.lock_acquire_time);
		System.out.println("Time taken for Logger Thread to finish execution of critical section: "+logg.critical_time);
		System.out.println();
	}
}
