package Project3;

import javax.realtime.*;

public class MotionPlanner extends RealtimeThread{
	int ct=0; //counter variable that is used to run the operation for multiple iterations
	long start_time; //time at which thread starts
	long end_time; //time at which thread ends
	long thread_execution_time; //time taken for thread to finish execution
	
	//This is thread is used to send commands to motor for movement (it runs for 7,500,000 iterations)
	public void run() {
		start_time=System.currentTimeMillis();
		System.out.println("Motion Planner Thread has Started at "+start_time);
		while(ct<7500000) {
			if(ct%500000==0) {
				System.out.println("Movement command sent to motor at "+System.currentTimeMillis());
			}
			ct++;
		}
		end_time=System.currentTimeMillis();
		System.out.println("Movement command finished at "+end_time);
		thread_execution_time=end_time-start_time;
			
	}
}
