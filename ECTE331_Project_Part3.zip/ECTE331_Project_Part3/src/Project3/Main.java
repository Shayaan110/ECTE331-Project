package Project3;

public class Main {
	
	public static void main(String[] args) throws InterruptedException{
		//demonstrating priority inversion first
		System.out.println("------------Priority Inversion------------");
		PriorityInversionDemo.runPInv();
		
		Thread.sleep(100);
		
		//demonstrating priority inheritance second
		System.out.println("\n------------Priority Inheritance------------");
		PriorityInheritanceDemo.runPInher();
		
		Thread.sleep(100);
		
		//demonstrating priority ceiling third
		System.out.println("\n------------Priority Ceiling------------");
		PriorityCeilingDemo.runPCeil();
		
	}
}
