package Project3;


public class MotorController {
	//creating the object that is shared by the threads
	final Object lock=new Object();
}
