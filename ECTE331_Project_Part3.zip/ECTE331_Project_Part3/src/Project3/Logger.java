package Project3;

import javax.realtime.*;

public class Logger extends RealtimeThread{
	int ct=0; //counter variable that is used to run the operation for multiple iterations
	MotorController MC; //an object created from the class that contains the shared resource
	long start_time; //time at which thread starts
	long end_time; //time at which thread ends
	long start_wait_time; //time at which thread is waiting for lock
	long end_wait_time; //time at which thread has acquired lock
	long thread_execution_time; //time taken for thread to finish execution
	long lock_acquire_time; //time taken for thread to acquire lock
	long critical_start_time; //time at which thread enters critical section
	long critical_end_time; //time at which thread exits critical section
	long critical_time; //execution time of the critical region
	
	//constructor for the thread to link it to the shared object
	public Logger(MotorController MC) {
		this.MC=MC;
	}
	
	//This is thread is used to log motor data (it runs for 7,500,000 iterations)
	//It has a lock on the shared object "lock" which belongs to Motor Controller object MC
	//It shares the lock with the SafetyMonitor Thread
	public void run() {
		start_time=System.currentTimeMillis();
		System.out.println("Logger Thread has started at "+start_time);
		start_wait_time=System.currentTimeMillis();
		System.out.println("Logger Thread waiting for the lock at "+start_wait_time);
		synchronized(MC.lock) {
			end_wait_time=System.currentTimeMillis();
			System.out.println("Logger Thread has the lock at "+end_wait_time);
			critical_start_time=end_wait_time;
			while(ct<7500000) {
				/*
				if (priority!=Thread.currentThread().getPriority()) {
					if(!ceiling_used) {
						System.out.println("The Logger Thread Priority has changed to "+Thread.currentThread().getPriority()+" at "+System.currentTimeMillis());
					}
					else {
						System.out.println("Ceiling in use at "+System.currentTimeMillis());
						System.out.println("The Logger Thread Priority has changed to "+Thread.currentThread().getPriority()+" at "+System.currentTimeMillis());
					}
					priority=Thread.currentThread().getPriority();
				}
				*/
				if (ct%500000==0) {
					System.out.println("Data is logged at "+System.currentTimeMillis());
				}
				ct++;
			}
		}
		critical_end_time=System.currentTimeMillis();
		critical_time=critical_end_time-critical_start_time;
		end_time=System.currentTimeMillis();
		System.out.println("Logger Thread has stopped at "+end_time);
		thread_execution_time=end_time-start_time;
		lock_acquire_time=end_wait_time-start_wait_time;
	}
}
