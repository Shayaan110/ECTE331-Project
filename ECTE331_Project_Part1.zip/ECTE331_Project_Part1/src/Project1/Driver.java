package Project1;

import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalTime;
import java.time.LocalDate;

/**
 * This is the Driver Class that is the main file that runs
 * 
 * @author Shayaan Katib
 * 
 */
public class Driver {
	/**
	 * the default method that runs
	 * Creates the sensor objects, does the majority voting, writes to file and console
	 * catches exception when Sensor Fails to get Data
	 * catches exception when system is no longer reliable
	 * 
	 * @param args (no argument passed)
	 * @throws SystemReliabilityException if system is no longer reliable (2 consecutive iterations with no updates in height)
	 * @throws IOException when system tries writing to the log file
	 */
	public static void main(String[] args) throws SystemReliabilityException, IOException{
		//creating a file handler
		FileWriter WritetoFile = null;
		try {
			System.out.println("--------------------------START--------------------------");
			WritetoFile=new FileWriter("data log.txt");
			WritetoFile.write("--------------------------START--------------------------\n");
			
		}
		catch(IOException ex) {
			ex.printStackTrace();
		}
		//creating sensor objects
		Sensor A=new Sensor("A");
		Sensor B=new Sensor("B");
		Sensor C=new Sensor("C");
		//initializing valA, valB, valC with garbage values to prevent exceptions
		int valA=-1, valB=-1, valC=-1;
		int height;
		//setting the previous height to be 200
		int prev_height=200;
		int failure_ct=0;
		int ct=0;
		while (true) {
			//writes the local sate and time to the console and log file
			LocalTime time=LocalTime.now();
			LocalDate date=LocalDate.now();
			WritetoFile.write("---------------------------------------------------------------\n");
			WritetoFile.write("Date: "+date+"\n");
			WritetoFile.write("Time: "+time+"\n");
			System.out.println("---------------------------------------------------------------");
			System.out.println("Date: "+date);
			System.out.println("Time: "+time);
			try {
				//System.out.println(failure_ct);
				//if 2 consecutive failures occur then a System Reliability Exception is thrown
				if (failure_ct==2) throw new SystemReliabilityException("System Entering Safe Mode");
				
				if (ct<16){
				    ct++;
				    failure_ct=0;
				    switch (ct){
				    	// all valid and match
					    case 1:
					        valA=valB=valC=A.readSensorTest();
					        A.setParameters();
					        B.setParameters();
					        C.setParameters();
					        break;
					    // all valid and two match
					    case 2:
					        valA=valB=A.readSensorTest();
					        do{
					        	valC=C.readSensorTest();
					        } while (valC==valA);
					        A.setParameters();
					        B.setParameters();
					        C.setParameters();
					        break;
					    // all valid and no match
					    case 3:
					        valA=A.readSensorTest();
					        do{
					        	valB=B.readSensorTest();
					        } while (valB==valA);
					        do{
					        	valC=C.readSensorTest();
					        } while (valC==valA || valC==valB);
					        A.setParameters();
					        B.setParameters();
					        C.setParameters();
					        break;
					    // two valid values that match and 1 corrupted
					    case 4:
					        valA=valB=A.readSensorTest();
					        valC=C.readSensorTestC();
					        A.setParameters();
					        B.setParameters();
					        C.sensor_failure=false;
					        break;
					    // two valid values that do not match and 1 corrupted
					    case 5:
					        valA=A.readSensorTest();
					        do{
					        	valB=B.readSensorTest();
					        } while (valB==valA);
					        valC=C.readSensorTestC();
					        A.setParameters();
					        B.setParameters();
					        C.sensor_failure = false;
					        break;
					    //two valid values that do match and 1 fail
					    case 6:
					        valA=valB=A.readSensorTest();
					        B.sensor_val = valB;
					        A.setParameters();
					        B.setParameters();
					        C.readSensorTestF();
					        break;
	
					    // two valid values that do not match and 1 fail
					    case 7:
					        valA=A.readSensorTest();
					        do{
					        	valB=B.readSensorTest(); 
					        } while (valB==valA);
					        A.setParameters();
					        B.setParameters();
					        C.readSensorTestF();
					        break;
	
					    // two corrupted values that match and 1 valid
					    case 8:
					        valA=A.readSensorTest();
					        valB=valC=B.readSensorTestC();
					        C.sensor_val=valC;
					        A.setParameters();
					        B.sensor_failure=false;
					        C.sensor_failure=false;
					        break;
	
					    //two corrupted values that do not match and 1 valid
					    case 9:
					        valA=A.readSensorTest();
					        valB=B.readSensorTestC();
					        do{
					        	valC=C.readSensorTestC(); 
					        } while (valC==valB);
					        A.setParameters();
					        B.sensor_failure=false;
					        C.sensor_failure=false;
					        break;
	
					    // 1 valid, 1 corrupted an 1 fail
					    case 10:
					        valA=A.readSensorTest();
					        valB=B.readSensorTestC();
					        A.setParameters();
					        B.sensor_failure=false;
					        C.readSensorTestF();
					        break;
	
					    //1 valid and 2 fails
					    case 11:
					        valA=A.readSensorTest();
					        A.setParameters();
					        B.readSensorTestF();
					        C.readSensorTestF();
					        break;
	
					    //all corrupted
					    case 12:
					        valA=A.readSensorTestC();
					        valB=B.readSensorTestC();
					        valC=C.readSensorTestC();
					        A.sensor_failure=false;
					        B.sensor_failure=false;
					        C.sensor_failure=false;
					        break;
	
					    //two corrupted values that match and 1 fail 
					    case 13:
					        valA=valB=A.readSensorTestC();
					        B.sensor_val=valB;
					        A.sensor_failure=false;
					        B.sensor_failure=false;
					        C.readSensorTestF();
					        break;
	
					    //two corrupted values that do not match and 1 fail 
					    case 14:
					        valA=A.readSensorTestC();
					        do{ 
					        	valB=B.readSensorTestC(); 
					        } while (valB==valA);
					        A.sensor_failure = false;
					        B.sensor_failure = false;
					        C.readSensorTestF();
					        break;
	
					    // 1 corrupted and two fail
					    case 15:
					        valA = A.readSensorTestC();
					        A.sensor_failure = false;
					        B.readSensorTestF();
					        C.readSensorTestF();
					        break;
	
					    // all fail
					    case 16:
					        A.readSensorTestF();
					        B.readSensorTestF();
					        C.readSensorTestF();
					        break;
					}
				}
				else{
					//normal execution
					valA = A.readSensor();
					valB = B.readSensor();
					valC = C.readSensor();
				}
				
				
				//writes the values of the sensor to the console and the log file
				WritetoFile.write("Sensor A: "+valA+"\n");
				WritetoFile.write("Sensor B: "+valB+"\n");
				WritetoFile.write("Sensor C: "+valC+"\n");
				System.out.println("Sensor A: "+valA);
				System.out.println("Sensor B: "+valB);
				System.out.println("Sensor C: "+valC);
				//checks to see if the sensors are corrupted and write it to the console and log file
				if (A.sensor_corrupted) {
					WritetoFile.write("Sensor A value is corrupted\n");
					System.out.println("Sensor A value is corrupted");
				}
				if (B.sensor_corrupted) {
					WritetoFile.write("Sensor B value is corrupted\n");
					System.out.println("Sensor B value is corrupted");
				}
				if (C.sensor_corrupted) {
					WritetoFile.write("Sensor C value is corrupted\n");
					System.out.println("Sensor C value is corrupted");
				}
				//If atleast 1 sensor is not corrupted it checks to see if a majority can be reached
				if (!A.sensor_corrupted||!B.sensor_corrupted||!C.sensor_corrupted) {
					if (valA==valB || valA==valC && !A.sensor_corrupted) {
						//sensor A value matches sensor B or sensor C and Sensor A is not corrupted
						//height is updated to the reading off sensor A
						failure_ct=0;
						height=valA;
						prev_height=height;
						WritetoFile.write("Majority has been reached (Height Updated)\n");
						System.out.println("Majority has been reached (Height Updated)");
					}
					else if(valB==valC && !B.sensor_corrupted){
						//sensor B value matches sensor C and Sensor B is not corrupted
						//height is updated to the reading off sensor B
						failure_ct=0;
						height=valB;
						prev_height=height;
						WritetoFile.write("Majority has been reached (Height Updated)\n");
						System.out.println("Majority has been reached (Height Updated)");
					}
					else {
						//no majority has been reached the height value falls back to its previous valid value
						failure_ct++;
						height=prev_height;
						WritetoFile.write("No Majority has been reached (Using Previous Height Value)\n");
						System.out.println("No Majority has been reached (Using Previous Height Value)");
					}
				}
				else {
					//all sensor values are corrupted the height value falls back to its previous valid value
					failure_ct++;
					height=prev_height;
					WritetoFile.write("No Majority has been reached (Using Previous Height Value)\n");
					System.out.println("No Majority has been reached (Using Previous Height Value)");
				}
				//Writes to log file and console the resulting height
				WritetoFile.write("Height: "+height+"\n");
				System.out.println("Height: "+height);
				//Writes to the file that the system is reliable
				WritetoFile.write("Reliable Status: Reliable\n");
				System.out.println("Reliable Status: Reliable");
				
				//resetting the boolean parameters of the sensors for the next iteration
				A.resetParameters();
				B.resetParameters();
				C.resetParameters();
				
			} 
			catch (SensorReadException e) {
				//executes if a sensor failure occurs
				e.printStackTrace(System.out);
				int sensor_fail_ct= 0;
				
				//checks to see if sensor has failed
				//if the sensor has failed it will write that the sensor has failed to the log file
				//if the sensor has not failed it will write the value of the sensor to the log file
				if (A.sensor_failure==true) {
					WritetoFile.write("Sensor A Failed\n");
					System.out.printf("Sensor A Failed\n");
					sensor_fail_ct++;
				}
				else {
					WritetoFile.write("Sensor A: "+A.sensor_val+"\n");
					System.out.println("Sensor A: "+A.sensor_val);
				}
				if (B.sensor_failure==true) {
					WritetoFile.write("Sensor B Failed\n");
					System.out.printf("Sensor B Failed\n");
					sensor_fail_ct++;
				}
				else {
					WritetoFile.write("Sensor B: "+B.sensor_val+"\n");
					System.out.println("Sensor B: "+B.sensor_val);
				}
				if (C.sensor_failure==true) {
					WritetoFile.write("Sensor C Failed\n");
					System.out.printf("Sensor C Failed\n");
					sensor_fail_ct++;
				}
				else {
					WritetoFile.write("Sensor C: "+C.sensor_val+"\n");
					System.out.println("Sensor C: "+C.sensor_val);
				}
				//checks to see if sensor value is corrupted (not failed) and writes to log file
				if (A.sensor_corrupted && !A.sensor_failure) {
					WritetoFile.write("Sensor A value is corrupted\n");
					System.out.println("Sensor A value is corrupted");
				}
				if (B.sensor_corrupted && !B.sensor_failure) {
					WritetoFile.write("Sensor B value is corrupted\n");
					System.out.println("Sensor B value is corrupted");
				}
				if (C.sensor_corrupted && !C.sensor_failure) {
					WritetoFile.write("Sensor C value is corrupted\n");
					System.out.println("Sensor C value is corrupted");
				}
				if (sensor_fail_ct>=2){
					//if more than 2 sensors have failed then the height value falls back to its previous valid value
					failure_ct++;
					height=prev_height;
					WritetoFile.write("No Majority has been reached (Using Previous Height Value)\n");
					System.out.println("No Majority has been reached (Using Previous Height Value)");
				}
				else {
					//if less than 2 sensors have failed the following will execute
					//If atleast 1 sensor is uncorrupted it checks to see if a majority can be reached
					if (!A.sensor_corrupted||!B.sensor_corrupted||!C.sensor_corrupted) {
						if (A.sensor_val==B.sensor_val || A.sensor_val==C.sensor_val && !A.sensor_corrupted) {
							//sensor A value matches sensor B or sensor C and Sensor A is not corrupted
							//height is updated to the reading off sensor A
							failure_ct=0;
							height=A.sensor_val;
							prev_height=height;
							WritetoFile.write("Majority has been reached (Height Updated)\n");
							System.out.println("Majority has been reached (Height Updated)");
						}
						else if(B.sensor_val==C.sensor_val && !B.sensor_corrupted){
							//sensor B value matches sensor C and Sensor B is not corrupted
							//height is updated to the reading off sensor B
							failure_ct=0;
							height=B.sensor_val;
							prev_height=height;
							WritetoFile.write("Majority has been reached (Height Updated)\n");
							System.out.println("Majority has been reached (Height Updated)");
						}
						else {
							//no majority has been reached the height value falls back to its previous valid value
							failure_ct++;
							height=prev_height;
							WritetoFile.write("No Majority has been reached (Using Previous Height Value)\n");
							System.out.println("No Majority has been reached (Using Previous Height Value)");
						}
					}
					else {
						//all sensors are corrupted the height value falls back to its previous valid value
						failure_ct++;
						height=prev_height;
						WritetoFile.write("No Majority has been reached (Using Previous Height Value)\n");
						System.out.println("No Majority has been reached (Using Previous Height Value)");
					}
				}
				//Writes to log file and console the resulting height
				WritetoFile.write("Height: "+height+"\n");
				System.out.println("Height: "+height);
				//Writes to the file that the system is reliable
				WritetoFile.write("Reliable Status: Reliable\n");
				System.out.println("Reliable Status: Reliable");
				
				//resetting the boolean parameters of the sensors for the next iteration
				A.resetParameters();
				B.resetParameters();
				C.resetParameters();
				
				//break;
			}
			catch (SystemReliabilityException ex) {
				//executes if a system reliability exception has occured
				//The systems reliable status is updated to not reliable and system goes into safe mode before ending its execution
				ex.printStackTrace(System.out);
				WritetoFile.write("Reliable Status: Not Reliable\n");
				WritetoFile.write("System has gone into Safe Mode\n");
				WritetoFile.write("--------------------------END--------------------------\n");
				System.out.println("Reliable Status: Not Reliable");
				System.out.println("System has gone into Safe mode");
				System.out.println("--------------------------END--------------------------");
				WritetoFile.close();
				break;
			}
		}
	}
}
