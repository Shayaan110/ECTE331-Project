package Project1;

/**
 * A class that implies that what happens when no majority has been reached for two consecutive iterations
 * 
 * @author Shayaan Katib
 * 
 */
public class SystemReliabilityException extends Exception{
	/**
	 * 
	 * @param message is the message that is passed from the if statement that throws the particular exception
	 */
	public SystemReliabilityException(String message) {
		super(message);
	}
}
