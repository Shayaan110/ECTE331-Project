package Project1;
import java.util.Random;

/**
 * This class is used to represent the sensors
 * 
 * @author Shayaan Katib
 * 
 */
public class Sensor {
	/**
	 * Unique Identifier of Sensor
	 */
	public String sensorID;
	/**
	 * current sensor reading
	 */
	public int sensor_val;
	/**
	 * boolean value to check if sensor is corrupted (true -> corrupted, false-> not corrupted)
	 */
	public boolean sensor_failure=true; 
	/**
	 * boolean value to check if sensor has failed (true -> failed, false-> not failed)
	 */
	public boolean sensor_corrupted=true; 
	
	//if sensor fails it is also considered corrupted (to make it simpler)
	
	/**
	 * constructor sets the Sensor ID
	 * 
	 * @param sensorID is used to set the ID of the sensor object
	 */
	public Sensor(String sensorID) {
		this.sensorID=sensorID;
	}
	

	/**
	 * method that is used to get value of sensor that is randomized 
	 * there is a chance the reading can be valid, corrupted or failed
	 * 
	 * @return a sensor reading
	 * @throws SensorReadException if sensor failed to get reading
	 */
	public int readSensor() throws SensorReadException{
		Random rand_value=new Random();
		Random rand_chance=new Random();
		int chance=rand_chance.nextInt(100);
		//if the chance is less than 15 the a Sensor Read Exception is thrown
		if (chance<15) throw new SensorReadException("Sensor Failure at Sensor "+sensorID);
		else if (chance>14 && chance<30) {
			//if the chance is greater than 14 and less than 15 the sensor has a corrupted value 
			sensor_failure=false;
			sensor_val=200+rand_value.nextInt(201);
			return sensor_val;
		}
		else{
			//otherwise sensor value is valid
			sensor_failure=false;
			sensor_corrupted=false;
			sensor_val=rand_value.nextInt(201);
			return sensor_val;
		}
	}
	
	/**
	 * Method that is used to force a valid sensor reading
	 * 
	 * @return a valid sensor reading
	 */
	public int readSensorTest() {
		Random rand_value=new Random();
		sensor_val=rand_value.nextInt(201);
		return sensor_val;
	}
	
	/**
	 * Method that is used to force a corrupted sensor reading
	 * 
	 * @return a corrupted sensor reading
	 */
	public int readSensorTestC() {
		Random rand_value=new Random();
		sensor_val=200+rand_value.nextInt(201);
		return sensor_val;
	}
	
	/**
	 * Method that is used to force a SensorReadException
	 * 
	 * @throws SensorReadException which indicates that the sensor failed to get a reading
	 */
	public void readSensorTestF() throws SensorReadException {
		if (true) throw new SensorReadException("Sensor Failure at Sensor "+sensorID);
	}
	
	/**
	 * Method that sets the boolean parameters to the false (sensor is not corrupted and has not failed)
	 */
	public void setParameters() {
		sensor_failure=false;
		sensor_corrupted=false;
	}
	
	/**
	 * Method that sets the boolean parameters to the true (sensor is corrupted and has failed)
	 */
	public void resetParameters() {
		sensor_failure=true;
		sensor_corrupted=true;
	}
	
}
