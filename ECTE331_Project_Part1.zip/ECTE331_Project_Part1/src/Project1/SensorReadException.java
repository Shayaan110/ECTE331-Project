package Project1;

import java.io.IOException;

/**
 * A class that implies that what happens when sensor fails to read
 * 
 * @author Shayaan Katib
 * 
 */
public class SensorReadException extends IOException{
	/**
	 * 
	 * @param message is the message that is passed from the if statement that throws the particular exception
	 */
	public SensorReadException(String message) {
		super(message);
	}
}
