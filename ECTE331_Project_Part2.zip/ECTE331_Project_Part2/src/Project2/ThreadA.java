package Project2;

public class ThreadA extends Thread{
	SharedResource SR;
	public ThreadA(SharedResource SR) {
		this.SR=SR;
	}
	
	private int FuncA1() {
		int add=Summation.Sum(500);
		return add;
	}
	
	private int FuncA2() {
		int add=SR.B2+Summation.Sum(300);
		return add;
	}
	
	private int FuncA3() {
		int add=SR.B3+Summation.Sum(400);
		return add;
	}
	
	
	public void run() {
		synchronized(SR) {
			SR.A1=FuncA1();
			SR.A1_done=true;
			SR.notify();
			//Thread waits until Function B2 is done
			while(!SR.B2_done) {
				try {
					SR.wait();
				}
				catch(InterruptedException e) {
					e.printStackTrace();
				}
			}
			SR.A2=FuncA2();
			SR.A2_done=true;
			SR.notify();
			//Thread waits until function B3 is done
			while(!SR.B3_done) {
				try {
					SR.wait();
				}
				catch(InterruptedException e) {
					e.printStackTrace();
				}
			}
			SR.A3=FuncA3();
		}
	}
}
