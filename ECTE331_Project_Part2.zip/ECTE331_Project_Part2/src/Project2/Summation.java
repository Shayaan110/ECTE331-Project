package Project2;

public final class Summation {
	public static int Sum(int n) {
		int j=0;
		for (int i=0;i<(n+1);i++) {
			j+=i;
		}
		return j;
	}
}
