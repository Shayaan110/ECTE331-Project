package Project2;

public final class Summation {
	//class to calculate summation using iteration
	public static int Sum(int n) {
		int j=0;
		for (int i=0;i<(n+1);i++) {
			j+=i;
		}
		return j;
	}
}
