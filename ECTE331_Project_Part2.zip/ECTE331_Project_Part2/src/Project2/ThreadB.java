package Project2;

public class ThreadB extends Thread{
	SharedResource SR;
	public ThreadB(SharedResource SR) {
		this.SR=SR;
	}
	
	private int FuncB1() {
		int add=Summation.Sum(250);
		return add;
	}
	
	private int FuncB2() {
		int add=SR.A1+Summation.Sum(200);
		return add;
	}
	
	private int FuncB3() {
		int add=SR.A2+Summation.Sum(400);
		return add;
	}
	
	
	public void run() {
		synchronized(SR) {
			SR.B1=FuncB1();
			SR.notify();
			//waits until function A1 is done
			while(!SR.A1_done) {
				try {
					SR.wait();
				}
				catch(InterruptedException e) {
					e.printStackTrace();
				}
			}
			SR.B2=FuncB2();
			SR.B2_done=true;
			SR.notify();
			//waits until function A2 is done
			while(!SR.A2_done) {
				try {
					SR.wait();
				}
				catch(InterruptedException e) {
					e.printStackTrace();
				}
			}
			SR.B3=FuncB3();
			SR.B3_done=true;
			SR.notify();
		}
	}
}
