package Project2;

public class ThreadB extends Thread{
	SharedResource SR; //object of shared resource
	
	//constructor to initialize Thread B and link it to the shared resource
	public ThreadB(SharedResource SR) {
		this.SR=SR;
	}
	
	//function B1
	//B1=summation (0,250)
	private int FuncB1() {
		int add=Summation.Sum(250);
		return add;
	}
	
	//function B2
	//B2=A1+summation (0,200)
	private int FuncB2() {
		int add=SR.A1+Summation.Sum(200);
		return add;
	}
	
	//function B3
	//B3=A2+summation (0,400)
	private int FuncB3() {
		int add=SR.A2+Summation.Sum(400);
		return add;
	}
	
	//thread execution code
	public void run() {
		synchronized(SR) {
			SR.B1=FuncB1();
			SR.notify();
			//waits until function A1 is done
			while(!SR.A1_done) {
				try {
					SR.wait();
				}
				catch(InterruptedException e) {
					e.printStackTrace();
				}
			}
			SR.B2=FuncB2();
			SR.B2_done=true;
			SR.notify();
			//waits until function A2 is done
			while(!SR.A2_done) {
				try {
					SR.wait();
				}
				catch(InterruptedException e) {
					e.printStackTrace();
				}
			}
			SR.B3=FuncB3();
			SR.B3_done=true;
			SR.notify();
		}
	}
}
