package Project2;

public class Main {
	public static void main(String[] args) {
		int[] expected= {125250,190500,350900,31375,145350,270700};
		//running the threads 10,000 times to check
		for (int i=0; i<10000; i++) {
			SharedResource SR=new SharedResource();
			ThreadA THA=new ThreadA(SR);
			ThreadB THB=new ThreadB(SR);
			THA.start();
			THB.start();
			try {
				THA.join();
				THB.join();
			}
			catch(InterruptedException e) {
				e.printStackTrace();
			}
			int[] SR_values= {SR.A1,SR.A2,SR.A3,SR.B1,SR.B2,SR.B3};
			//prints out the values of A1, A2, A3, B1, B2, B3 if the values don't match the expected values in a cycle
			for (int j=0; j<SR_values.length;j++) {
				if(expected[j]!=SR_values[j]) {
					System.out.println("Unexpected values at Interation number: "+i);
					System.out.printf("A1: %d A2: %d A3: %d\n",SR.A1,SR.A2,SR.A3);
					System.out.printf("B1: %d B2: %d B3: %d\n",SR.B1,SR.B2,SR.B3);
					System.out.println("------------------------------------------");
					break;
				}
			}
			
			//print out all the calculated values of A1, A2, A3, B1, B2, B3 in all cycles
			//(can comment this out to check more effectively)
			
			System.out.println("Interation number: "+i);
			System.out.printf("A1: %d A2: %d A3: %d\n",SR.A1,SR.A2,SR.A3);
			System.out.printf("B1: %d B2: %d B3: %d\n",SR.B1,SR.B2,SR.B3);
			System.out.println("------------------------------------------");
			
			
		}
		System.out.println("----------------------------END----------------------------");
	}
}
