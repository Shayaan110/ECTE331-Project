package Project2;

public class SharedResource {
	//the resources shared among Threads A and B
	public int A1, A2, A3; //shared variables A1, A2 and A3
	public int B1, B2, B3; //shared variables A1, A2 and A3
	boolean A1_done=false; //variable to check if function A1 has finished executing
	boolean B2_done=false; //variable to check if function B2 has finished executing
	boolean A2_done=false; //variable to check if function A2 has finished executing
	boolean B3_done=false; //variable to check if function B3 has finished executing
}
