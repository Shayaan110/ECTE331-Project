package Project2;

public class SharedResource {
	//the resources shared among Threads A and B
	public int A1, A2, A3;
	public int B1, B2, B3;
	boolean A1_done=false;
	boolean B2_done=false;
	boolean A2_done=false;
	boolean B3_done=false;
}
